import React, { useState } from 'react';

function App() {
  const [wallet, setWallet] = useState("");

  async function connectWallet() {
    const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
    setWallet(accounts[0]);
  }

  return (
    <div>
      <h1>Crypto Exchange Dashboard</h1>
      <button onClick={connectWallet}>Connect Wallet</button>
      <p>{wallet}</p>
    </div>
  );
}

export default App;
